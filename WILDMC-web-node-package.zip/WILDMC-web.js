#!/usr/bin/env node
/**
 * WILDMC Node.js entry point (compatibility bridge)
 *
 * This starts the existing WILDMC Python application from Node.js so its
 * routes, Discord OAuth, database format, uploads and WebSocket behavior
 * remain intact while you migrate the backend incrementally.
 *
 * Requirements: Node.js 18+ and Python 3.
 * Run: node WILDMC-web.js
 */
'use strict';

const { spawn } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const root = __dirname;
const pythonFile = path.join(root, 'WILDMC-web.py');

if (!fs.existsSync(pythonFile)) {
  console.error('[WILDMC] WILDMC-web.py not found.');
  console.error('[WILDMC] Keep WILDMC-web.js and WILDMC-web.py in the same directory.');
  process.exit(1);
}

const candidates = process.platform === 'win32'
  ? ['py', 'python']
  : ['python3', 'python'];

function launch(index) {
  if (index >= candidates.length) {
    console.error('[WILDMC] Python 3 was not found. Install Python 3 or add it to PATH.');
    process.exit(1);
  }

  const command = candidates[index];
  const args = command === 'py' ? ['-3', pythonFile] : [pythonFile];
  const child = spawn(command, args, {
    cwd: root,
    env: process.env,
    stdio: 'inherit',
    windowsHide: true
  });

  child.once('error', (err) => {
    if (err.code === 'ENOENT') return launch(index + 1);
    console.error('[WILDMC] Failed to start backend:', err.message);
    process.exit(1);
  });

  child.once('exit', (code, signal) => {
    if (signal) {
      console.error(`[WILDMC] Backend stopped by ${signal}`);
      process.exit(1);
    }
    process.exit(code ?? 0);
  });

  const stop = (signal) => {
    if (!child.killed) child.kill(signal);
  };
  process.once('SIGINT', () => stop('SIGINT'));
  process.once('SIGTERM', () => stop('SIGTERM'));
}

launch(0);
