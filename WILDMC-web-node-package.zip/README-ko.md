# WILDMC Web — Node.js 실행 패키지

## 실행
1. `WILDMC-web.js`, `WILDMC-web.py`, `package.json`을 같은 폴더에 둡니다.
2. Node.js 18 이상과 Python 3가 설치되어 있어야 합니다.
3. 실행: `npm start` 또는 `node WILDMC-web.js`
4. 기본 접속 주소: `http://서버주소:3000`

## 중요
이 버전은 **완전한 Python→JavaScript 포팅이 아니라 Node.js 실행 진입점(호환 브리지)** 입니다.
기존 기능과 DB/API 동작을 빠르게 유지하기 위해 Python 서버를 Node.js에서 실행합니다.
따라서 Python 파일을 삭제하면 실행되지 않습니다. 순수 Node.js로 완전 이전하려면
라우트·인증·DB·업로드·WebSocket·백그라운드 작업을 기능별로 다시 구현하고 테스트해야 합니다.

기존 `.env`와 `data/` 폴더는 기존 서버와 같은 위치에 유지하세요.
